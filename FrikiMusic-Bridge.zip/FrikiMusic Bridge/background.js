

const ORIGINS = ["http://localhost", "http://127.0.0.1", "https://frikimusic.org", "https://www.frikimusic.org", "https://frikimusictest1.vercel.app"];
const YT = "https://music.youtube.com", WWW = "https://www.youtube.com";
const SONGS = "EgWKAQIIAWoMEA4QChADEAQQCRAF";
const WEB = { client: { clientName: "WEB_REMIX", clientVersion: "1.20260818.08.00", hl: "en", gl: "US" } };

const set = (header, value) => ({ header, operation: "set", value });
const remove = header => ({ header, operation: "remove" });
const CORS = [set("Access-Control-Allow-Origin", "*"), set("Access-Control-Expose-Headers", "*")];
const as = o => [set("Origin", o), set("Referer", o + "/"), set("X-Origin", o)];
const XHR = ["xmlhttprequest"], MEDIA = ["xmlhttprequest", "media"];

function pageRules(domains) {
  const r = (id, urlFilter, req, types = XHR, priority = 1) => ({
    id, priority, condition: { urlFilter, initiatorDomains: domains, resourceTypes: types },
    action: { type: "modifyHeaders", ...(req && { requestHeaders: req }), responseHeaders: CORS },
  });
  return [
    r(1, "||music.youtube.com/youtubei/", as(YT)),
    r(2, "||www.youtube.com/youtubei/", as(WWW)),
    r(3, "||www.youtube.com/sw.js_data", null),
    r(4, "||www.youtube.com/iframe_api", null),
    r(5, "||www.youtube.com/s/player/", null),
    r(6, "||googlevideo.com/", as(WWW).slice(0, 2), MEDIA),

    r(7, "||googlevideo.com/*c=VISIONOS", [remove("Origin"), remove("Referer")], MEDIA, 2),
  ];
}
async function installRules() {
  const domains = [...new Set(ORIGINS.map(o => new URL(o).hostname))];
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: Array.from({ length: 99 }, (_, i) => i + 1), addRules: pageRules(domains) });

  const own = (id, host, origin) => ({ id, priority: 1, condition: { urlFilter: `||${host}/`, tabIds: [-1], resourceTypes: XHR },
    action: { type: "modifyHeaders", requestHeaders: as(origin).slice(0, 2) } });
  await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [100, 101],
    addRules: [own(100, "www.youtube.com", WWW), own(101, "music.youtube.com", YT)] });
}
chrome.runtime.onInstalled.addListener(installRules);
chrome.runtime.onStartup.addListener(installRules);
installRules().catch(e => console.error("FrikiMusic: no se pudieron instalar las reglas", e));

let indexCache = null;
async function secret() {
  for (const n of ["SAPISID", "__Secure-3PAPISID", "__Secure-1PAPISID"]) {
    const c = await chrome.cookies.get({ url: YT + "/", name: n }).catch(() => null);
    if (c?.value) return c.value;
  }
  return null;
}
async function sign(value, origin) {
  const t = Math.floor(Date.now() / 1e3);
  const d = await crypto.subtle.digest("SHA-1", new TextEncoder().encode(`${t} ${value} ${origin}`));
  return `SAPISIDHASH ${t}_${[...new Uint8Array(d)].map(b => b.toString(16).padStart(2, "0")).join("")}`;
}
async function sessionIndex(value) {
  if (indexCache && Date.now() - indexCache.at < 6e5) return indexCache.value;
  let found = "0";
  try {
    const r = await fetch(YT + "/", { credentials: "include", headers: { Authorization: await sign(value, YT), "X-Goog-AuthUser": "0", "X-Origin": YT } });
    found = /"SESSION_INDEX":"?(\d+)/.exec(await r.text())?.[1] ?? "0";
  } catch {}
  indexCache = { value: found, at: Date.now() };
  return found;
}
async function authHeaders(origin = YT) {
  const value = await secret();
  if (!value) return {};
  return { Authorization: await sign(value, origin), "X-Goog-AuthUser": await sessionIndex(value), "X-Origin": origin };
}
const walk = (o, key, out = []) => { if (o && typeof o === "object") for (const k in o) k === key ? out.push(o[k]) : walk(o[k], key, out); return out; };
const runs = c => c?.musicResponsiveListItemFlexColumnRenderer?.text?.runs || [];

const VIDEOS = "EgWKAQIQAWoMEA4QChADEAQQCRAF";
const TYPE = x => x?.watchEndpoint?.watchEndpointMusicSupportedConfigs?.watchEndpointMusicConfig?.musicVideoType || "";

const isVideo = t => !!t && t !== "MUSIC_VIDEO_TYPE_ATV";
const KIND = /^(song|video|canción|cancion|vídeo|single|ep|álbum|album)$/i;
const thumb = th => th?.at(-1)?.url || "";

function groups(rs) {
  const out = [""];
  for (const r of rs) { if (r.text.trim() === "•") out.push(""); else out[out.length - 1] += r.text; }
  const g = out.map(x => x.trim()).filter(Boolean);
  if (g.length && KIND.test(g[0])) g.shift();
  return g;
}
function subtitle(rs) { const g = groups(rs); return { artist: g[0] || "", meta: g.slice(1).join(" · ") }; }

function listItem(x) {
  const id = x.playlistItemData?.videoId; if (!id) return null;
  const type = TYPE(x.overlay?.musicItemThumbnailOverlayRenderer?.content?.musicPlayButtonRenderer?.playNavigationEndpoint)
    || TYPE(x.flexColumns[0]?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.[0]?.navigationEndpoint);
  const g = groups(runs(x.flexColumns[1]));
  const timed = /^\d+:\d{2}/.test(g.at(-1) || "");
  return { id, title: runs(x.flexColumns[0]).map(t => t.text).join(""), artist: g[0] || "", meta: g.slice(1).join(" · "), album: timed && g.length > 2 ? g[1] : null, cover: thumb(x.thumbnail?.musicThumbnailRenderer?.thumbnail?.thumbnails), video: isVideo(type) };
}

function cardItem(x) {
  const ep = x.navigationEndpoint, id = ep?.watchEndpoint?.videoId; if (!id) return null;
  const { artist, meta } = subtitle(x.subtitle?.runs || []);
  return { id, title: (x.title?.runs || []).map(r => r.text).join(""), artist, meta, cover: thumb(x.thumbnailRenderer?.musicThumbnailRenderer?.thumbnail?.thumbnails), video: isVideo(TYPE(ep)) };
}
const post = async (path, body, query = "") => {
  const r = await fetch(`${YT}/youtubei/v1/${path}?prettyPrint=false${query}`, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json", ...(await authHeaders()) }, body: JSON.stringify({ context: WEB, ...body }) });
  if (!r.ok) throw new Error(`YouTube respondió ${r.status}`);
  return r.json();
};
async function searchOne(query, params) {
  return walk(await post("search", { query, params }), "musicResponsiveListItemRenderer").map(listItem).filter(Boolean);
}

async function search({ query }) {
  const [songs, vids] = await Promise.all([searchOne(query, SONGS), searchOne(query, VIDEOS).catch(() => [])]);
  const seen = new Set(), out = [];
  for (let i = 0; i < Math.max(songs.length, vids.length); i++) for (const x of [songs[i], vids[i]]) if (x && !seen.has(x.id)) { seen.add(x.id); out.push(x); }
  return out;
}

async function home() {
  const json = await post("browse", { browseId: "FEmusic_home" });
  const sections = [];
  for (const sh of walk(json, "musicCarouselShelfRenderer")) {
    const title = sh.header?.musicCarouselShelfBasicHeaderRenderer?.title?.runs?.map(r => r.text).join("") || "";
    const items = (sh.contents || []).map(c => c.musicTwoRowItemRenderer ? cardItem(c.musicTwoRowItemRenderer) : c.musicResponsiveListItemRenderer ? listItem(c.musicResponsiveListItemRenderer) : null).filter(Boolean);
    if (title && items.length) sections.push({ title, items });
  }
  return sections;
}

async function homeRaw() {
  const pages = [await post("browse", { browseId: "FEmusic_home" })];
  let token = walk(pages[0], "nextContinuationData")[0]?.continuation;
  for (let n = 0; token && n < 5; n++) {
    const next = await post("browse", { continuation: token }, `&ctoken=${encodeURIComponent(token)}&continuation=${encodeURIComponent(token)}&type=next`);
    pages.push(next);
    token = walk(next, "nextContinuationData")[0]?.continuation;
  }
  return pages;
}

const YT_ALLOWED = /^https:\/\/(music|www)\.youtube\.com\/youtubei\/v1\//;
const IDENTITY = ["authorization", "cookie", "x-goog-authuser", "x-goog-pageid", "x-origin", "origin", "referer"];
async function ytfetch({ url, method = "GET", headers = {}, body }) {
  if (!YT_ALLOWED.test(url)) throw new Error("ytfetch no sirve " + url);
  const auth = await authHeaders(new URL(url).origin);
  if (!auth.Authorization) throw new Error("El navegador no tiene sesión de YouTube Music.");
  const clean = {};
  for (const [k, v] of Object.entries(headers)) if (!IDENTITY.includes(k.toLowerCase())) clean[k] = v;
  const r = await fetch(url, { method, headers: { ...clean, ...auth }, body: body ?? null, credentials: "include" });
  const out = {};
  r.headers.forEach((v, k) => { out[k] = v; });
  return { status: r.status, headers: out, url: r.url, bodyEncoding: "text", body: await r.text() };
}

const LYRIC_HOSTS = new Set(["lrc.red", "lyrics-api.binimum.org", "lyrics-api.boidu.dev", "unison.boidu.dev", "lyricsplus.prjktla.my.id", "lyricsplus.binimum.org", "lrclib.net"]);
async function lyrics({ url }) {
  const u = new URL(url);
  if (u.protocol !== "https:" || !LYRIC_HOSTS.has(u.hostname)) throw new Error("Host de letras no permitido");
  const r = await fetch(u, { credentials: "omit", headers: { Accept: "application/json, text/plain, */*" }, signal: AbortSignal.timeout(15000) });
  return r.ok ? await r.text() : null;
}

const methods = {
  rules: async () => ({ ids: (await chrome.declarativeNetRequest.getDynamicRules()).map(r => r.id), session: (await chrome.declarativeNetRequest.getSessionRules()).map(r => r.id) }),
  ping: async () => ({ version: chrome.runtime.getManifest().version }), search, home, homeRaw, ytfetch, lyrics };
chrome.runtime.onMessageExternal.addListener((m, sender, reply) => {
  const o = sender.origin || "";
  if (m?.channel !== "friki-bridge" || !(ORIGINS.includes(o) || (o.startsWith("http://localhost") || o.startsWith("http://127.0.0.1")))) { reply({ ok: false, error: "Origen no permitido" }); return false; }
  (methods[m.method] ? methods[m.method](m.params || {}) : Promise.reject(new Error("La web está desactualizada: recarga con Ctrl+Shift+R (método " + m?.method + ")")))
    .then(result => reply({ ok: true, result })).catch(e => reply({ ok: false, error: e.message }));
  return true;
});
